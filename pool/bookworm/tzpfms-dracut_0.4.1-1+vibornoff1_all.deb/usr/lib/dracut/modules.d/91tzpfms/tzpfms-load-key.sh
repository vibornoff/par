#!/bin/sh
# SPDX-License-Identifier: MIT


# SPDX-License-Identifier: MIT






	# This sucks a lot of ass, since we don't know the questions or the amount thereof beforehand
	# (0-2 (owner hierarchy/ownership + sealed object, both optional) best-case and 0-6 worst-case (both entered wrong twice)).
	with_promptable_tty() {
		if plymouth --ping 2>/dev/null; then
			# shellcheck disable=SC2016
			TZPFMS_PASSPHRASE_HELPER='exec plymouth ask-for-password --prompt="$1: "' "$@" 2>/run/tzpfms-err; ret="$?"
			[ -s /run/tzpfms-err ] && plymouth display-message --text="$(cat /run/tzpfms-err)"
		elif [ -e /run/systemd/system ] && command -v systemd-ask-password > /dev/null; then  # --no-tty matches zfs and actually works
			# shellcheck disable=SC2016
			TZPFMS_PASSPHRASE_HELPER='exec systemd-ask-password --no-tty --id="tzpfms:$2" "$1:"' "$@" 2>/run/tzpfms-err; ret="$?"
		else
			# Mimic /scripts/zfs#decrypt_fs(): setting "printk" temporarily to "7" will allow prompt even if kernel option "quiet"
			read -r printk _ < /proc/sys/kernel/printk
			[ "$printk" = "7" ] || echo 7 > /proc/sys/kernel/printk

			TZPFMS_PASSPHRASE_HELPER="${TZPFMS_PASSPHRASE_HELPER:-}" "$@" < /dev/console > /dev/console 2>&1; ret="$?"  # allow overriding in cmdline, but always set to raze default

			[ "$printk" = "7" ] || echo "$printk" > /proc/sys/kernel/printk
		fi
		[ -s /run/tzpfms-err ] && cat /run/tzpfms-err >&2
		[ -s /run/tzpfms-err ] && [ "$ret" -ne 0 ] && sed 's;^;'"$1"': ;' /run/tzpfms-err >> /dev/kmsg
		rm -f /run/tzpfms-err
		return "$ret"
	}

# SPDX-License-Identifier: 0BSD
# dbda45160ffa43e5ecf0498a609230f1afee7b3f (zfs-2.2.99-270-gdbda45160)


# for_relevant_root_children DATASET EXEC
#   Runs "EXEC dataset mountpoint" for all children of DATASET that are needed for system bringup
#   Used by zfs-nonroot-necessities.service and friends, too!
for_relevant_root_children() {
    dataset="${1}"
    exec="${2}"

    zfs list -t filesystem -Ho name,mountpoint,canmount -r "${dataset}" |
        (
            _ret=0
            while IFS="	" read -r dataset mountpoint canmount; do
                [ "$canmount" != "on" ] && continue

                case "$mountpoint" in
                    /etc|/bin|/lib|/lib??|/libx32|/usr)
                        # If these aren't mounted we may not be able to get to the real init at all, or pollute the dataset holding the rootfs
                        "${exec}" "${dataset}" "${mountpoint}" || _ret=$?
                        ;;
                    *)
                        # Up to the real init to remount everything else it might need
                        ;;
                esac
            done
            exit "${_ret}"
        )
}

# Parse root=, rootfstype=, return them decoded and normalised to zfs:AUTO for auto, plain dset for explicit
#
# True if ZFS-on-root, false if we shouldn't
#
# Supported values:
#   root=
#   root=zfs
#   root=zfs:
#   root=zfs:AUTO
#
#   root=ZFS=data/set
#   root=zfs:data/set
#   root=zfs:ZFS=data/set (as a side-effect; allowed but undocumented)
#
#   rootfstype=zfs AND root=data/set <=> root=data/set
#   rootfstype=zfs AND root=         <=> root=zfs:AUTO
#
# '+'es in explicit dataset decoded to ' 's.
decode_root_args() {
    if [ -n "$rootfstype" ]; then
        [ "$rootfstype" = zfs ]
        return
    fi

    xroot=$(getarg root=)
    rootfstype=$(getarg rootfstype=)

    # shellcheck disable=SC2249
    case "$xroot" in
        ""|zfs|zfs:|zfs:AUTO)
            root=zfs:AUTO
            rootfstype=zfs
            return 0
            ;;

        ZFS=*|zfs:*)
            root="${xroot#zfs:}"
            root="${root#ZFS=}"
            root=$(echo "$root" | tr '+' ' ')
            rootfstype=zfs
            return 0
            ;;
    esac

    if [ "$rootfstype" = "zfs" ]; then
        case "$xroot" in
            "") root=zfs:AUTO ;;
            *)  root=$(echo "$xroot" | tr '+' ' ') ;;
        esac
        return 0
    fi

    return 1
}


# Only run on systemd systems, mimicking zfs-dracut's zfs-load-key.sh; TODO: "see mount-zfs.sh for non-systemd systems", confer README
[ -d /run/systemd ] || return 0


. "/lib/dracut-lib.sh"
decode_root_args || return 0


# There is a race between the zpool import and the pre-mount hooks, so we wait for a pool to be imported
while ! systemctl is-active --quiet zfs-import.target; do
    systemctl is-failed --quiet zfs-import-cache.service zfs-import-scan.service && return 1
    sleep 0.1s
done

BOOTFS="$root"
if [ "$BOOTFS" = "zfs:AUTO" ]; then
    BOOTFS="$(zpool get -Ho value bootfs | grep -m1 -vFx -)"
fi

[ "$(zpool get -Ho value feature@encryption "${BOOTFS%%/*}")" = 'active' ] || return 0


getarg 0 quiet && quiet=y


tzpfms_load() {
    set -- "$(zfs get -Ho value encryptionroot "$1")"
    [ "$1" = "-" ] && return 0

    # Match this sexion to i-t/zfs-patch.sh
    if command -v zfs-tpm2-load-key > /dev/null && [ -n "$(zfs-tpm-list -Hub TPM2 "$1")" ]; then
        with_promptable_tty zfs-tpm2-load-key "$1"
        return
    fi

    if command -v zfs-tpm1x-load-key > /dev/null && [ -n "$(zfs-tpm-list -Hub TPM1.X "$1")" ]; then
        	[ -z "$TZPFMS_TPM1X" ] && command -v tcsd > /dev/null && {
		ip l | awk -F '[[:space:]]*:[[:space:]]*' '{if($2 == "lo") exit $3 ~ /UP/}'
		lo_was_up="$?"
		if [ "$lo_was_up" = "0" ]; then
			ip l set up dev lo
			while ! ip a show dev lo | grep -qE '::1|127.0.0.1'; do sleep 0.1; done
		fi

		if [ "${quiet:-n}" = "y" ]; then
			tcsd -f > /tcsd.log 2>&1 &
		else
			tcsd -f > /dev/console 2>&1 &
		fi
		tcsd_port="$(awk -F '[[:space:]]*=[[:space:]]*' '!/^[[:space:]]*#/ && !/^$/ && $1 ~ /port$/ {gsub(/[[:space:]]/, "", $2); print $2}' /etc/tcsd.conf)"
		i=0; while [ "$i" -lt 100 ] && ! ss -ltO | grep -q "${tcsd_port:-30003}"; do sleep 0.1; i="$((i + 1))"; done
		[ "$i" = 100 ] && echo "Couldn't start tcsd!" >&2
	}

        with_promptable_tty zfs-tpm1x-load-key "$1"; err="$?"
        	[ -z "$TZPFMS_TPM1X" ] && command -v tcsd > /dev/null && {
		kill %+

		if [ "$lo_was_up" = "0" ]; then
			ip l set down dev lo
			# ::1 removed automatically
			ip a del 127.0.0.1/8 dev lo 2>/dev/null
		fi
	}

        return "$err"
    fi
}


tzpfms_load "$BOOTFS"
for_relevant_root_children "$BOOTFS" tzpfms_load
