#!/bin/sh
# SPDX-License-Identifier: MIT
# shellcheck disable=SC2086


# SPDX-License-Identifier: MIT




_get_backend() {
	OIFS="$IFS"
	IFS='
'
	rootfses="$(awk '$2 ~ "^(/|/etc|/bin|/lib|/lib??|/libx32|/usr)$" && $3 == "zfs" {print $1}' /etc/mtab)"
	[ -z "$rootfses" ] && IFS="$OIFS" && return 1

	eroots="$(zfs get encryptionroot -Ho value $rootfses | sort -u | grep -vFxe '' -e '-')"
	[ -z "$eroots" ] && IFS="$OIFS" && return 1

	backends="$(zfs-tpm-list -H $eroots | cut -f2 | sort -u)"
	[ -z "$backends" ] && IFS="$OIFS" && return 1

	IFS="$OIFS"
	return 0
}

_install_tpm2() {
	inst_binary zfs-tpm2-load-key
	inst_libdir_file 'libtss2-tcti*.so*'
	command -v tpm2_dictionarylockout > /dev/null && inst_binary tpm2_dictionarylockout
}

_install_tpm1x() {
	inst_binary zfs-tpm1x-load-key
		command -v tcsd > /dev/null && {
		inst_binary tcsd; inst_binary ip; inst_binary ss

		# tcsd exits if it doesn't have tss group and user
		grep tss /etc/group  >> "${initdir:?must exist}/etc/group"
		grep tss /etc/passwd >> "${initdir:?must exist}/etc/passwd"

		for f in /lib/udev/rules.d/*tpm*; do
			inst_simple "$f"
		done

		if [ -e /etc/tcsd.conf ]; then
			inst_simple /etc/tcsd.conf
			chown root:tss "${initdir:?must exist}/etc/tcsd.conf"
			system_ps_file="$(awk -F '[[:space:]]*=[[:space:]]*' '!/^[[:space:]]*#/ && !/^$/ && $1 ~ /system_ps_file$/ {gsub(/[[:space:]]*$/, "", $2); print $2}' /etc/tcsd.conf)"
			system_ps_file="${system_ps_file:-/var/lib/tpm/system.data}"
		fi

		# tcsd can't find SRK if state not present, refuses to start if it doesn't have parent to tss dir
		mkdir -p "${initdir:?must exist}/$(dirname "$(dirname "$system_ps_file")")"
		[ -f "$system_ps_file" ] && inst_simple "$system_ps_file"
	}

	# localhost needs to resolve at the very least
	for f in /etc/hosts /etc/resolv.conf /etc/host.conf /etc/gai.conf; do
		[ -e "$f" ] && inst_simple "$f"
	done

	if [ -e /etc/nsswitch.conf ]; then
		inst_simple /etc/nsswitch.conf
		databases="$(awk '/^(group|hosts)/ {for(i = 2; i <= NF; ++i) if($i !~ /[^a-z0-9_-]/) db[$i]=0}  END {for(d in db) print d}' /etc/nsswitch.conf)"
		for db in $databases; do
			for f in /lib/*/"libnss_$db"*; do
				inst_libdir_file "$f"
			done
		done
	fi

	command -v tpm_resetdalock > /dev/null && inst_binary tpm_resetdalock
}


check() {
	require_binaries zfs-tpm-list || return

	# shellcheck disable=SC2154
	if [ -n "$hostonly" ]; then
		_get_backend || return

		for backend in $backends; do
			[ "$backend" = "TPM2"   ] && command -v zfs-tpm2-load-key  > /dev/null && return 0
			[ "$backend" = "TPM1.X" ] && command -v zfs-tpm1x-load-key > /dev/null && return 0
		done

		return 1
	fi

	return 0
}


depends() {
	echo zfs
}


installkernel() {
	instmods '=drivers/char/tpm'
}


install() {
	inst_binary zfs-tpm-list

	if [ -n "$hostonly" ]; then
		_get_backend

		for backend in $backends; do
			[ "$backend" = "TPM2"   ] && _install_tpm2
			[ "$backend" = "TPM1.X" ] && _install_tpm1x
		done
	else
		command -v zfs-tpm2-load-key  > /dev/null && _install_tpm2
		command -v zfs-tpm1x-load-key > /dev/null && _install_tpm1x
	fi

	inst_hook pre-mount 89 "${moddir:-}/tzpfms-load-key.sh"  # zfs installs with 90, we *must* run beforehand
}
